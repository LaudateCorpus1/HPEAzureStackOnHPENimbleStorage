. $PSScriptRoot\scripts\helpers.ps1
. $PSScriptRoot\scripts\VolumeCollection.ps1
. $PSScriptRoot\scripts\AccessControlRecord.ps1
. $PSScriptRoot\scripts\Token.ps1
. $PSScriptRoot\scripts\UserGroup.ps1
. $PSScriptRoot\scripts\ChapUser.ps1
. $PSScriptRoot\scripts\Witness.ps1
. $PSScriptRoot\scripts\Pool.ps1
. $PSScriptRoot\scripts\FibreChannelInitiatorAlias.ps1
. $PSScriptRoot\scripts\ProtectionTemplate.ps1
. $PSScriptRoot\scripts\InitiatorGroup.ps1
. $PSScriptRoot\scripts\Snapshot.ps1
. $PSScriptRoot\scripts\Volume.ps1
. $PSScriptRoot\scripts\Subnet.ps1
. $PSScriptRoot\scripts\ActiveDirectoryMembership.ps1
. $PSScriptRoot\scripts\SpaceDomain.ps1
. $PSScriptRoot\scripts\Group.ps1
. $PSScriptRoot\scripts\ReplicationPartner.ps1
. $PSScriptRoot\scripts\Folder.ps1
. $PSScriptRoot\scripts\NetworkConfig.ps1
. $PSScriptRoot\scripts\Controller.ps1
. $PSScriptRoot\scripts\ProtectionSchedule.ps1
. $PSScriptRoot\scripts\MasterKey.ps1
. $PSScriptRoot\scripts\ApplicationServer.ps1
. $PSScriptRoot\scripts\Event.ps1
. $PSScriptRoot\scripts\FibreChannelPort.ps1
. $PSScriptRoot\scripts\ApplicationCategory.ps1
. $PSScriptRoot\scripts\AuditLog.ps1
. $PSScriptRoot\scripts\Initiator.ps1
. $PSScriptRoot\scripts\Version.ps1
. $PSScriptRoot\scripts\PerformancePolicy.ps1
. $PSScriptRoot\scripts\Job.ps1
. $PSScriptRoot\scripts\Disk.ps1
. $PSScriptRoot\scripts\NetworkInterface.ps1
. $PSScriptRoot\scripts\UserPolicy.ps1
. $PSScriptRoot\scripts\SoftwareVersion.ps1
. $PSScriptRoot\scripts\SnapshotCollection.ps1
. $PSScriptRoot\scripts\FibreChannelConfig.ps1
. $PSScriptRoot\scripts\User.ps1
. $PSScriptRoot\scripts\Shelf.ps1
. $PSScriptRoot\scripts\ProtocolEndpoint.ps1
. $PSScriptRoot\scripts\FibreChannelInterface.ps1
. $PSScriptRoot\scripts\FibreChannelSession.ps1
. $PSScriptRoot\scripts\Array.ps1
. $PSScriptRoot\scripts\Alarm.ps1

Export-ModuleMember -Function Test-NS2PasswordFormat,   Test-Ns2Type,   Test-NS2ID,     Connect-NSGroup,  Disconnect-NSGroup,
    New-NSVolumeCollection,    Get-NSVolumeCollection,    Set-NSVolumeCollection,    Remove-NSVolumeCollection,   
    Invoke-NSVolumeCollectionPromote,    Invoke-NSVolumeCollectionDemote,    Start-NSVolumeCollectionHandover,    Stop-NSVolumeCollectionHandover,   
    Test-NSVolumeCollection,    New-NSAccessControlRecord,    Get-NSAccessControlRecord,    Remove-NSAccessControlRecord,   
    New-NSToken,    Get-NSToken,    Remove-NSToken,    Get-NSTokenUserDetails,   
    New-NSUserGroup,    Get-NSUserGroup,    Set-NSUserGroup,    Remove-NSUserGroup,   
    New-NSChapUser,    Get-NSChapUser,    Set-NSChapUser,    Remove-NSChapUser,   
    New-NSWitness,    Get-NSWitness,    Remove-NSWitness,    Test-NSWitness,   
    New-NSPool,    Get-NSPool,    Set-NSPool,    Remove-NSPool,   
    Merge-NSPool,    Invoke-NSPoolDeDupe,    Get-NSFibreChannelInitiatorAlias,    New-NSProtectionTemplate,   
    Get-NSProtectionTemplate,    Set-NSProtectionTemplate,    Remove-NSProtectionTemplate,    New-NSInitiatorGroup,   
    Get-NSInitiatorGroup,    Set-NSInitiatorGroup,    Remove-NSInitiatorGroup,    Resolve-NSInitiatorGroupMerge,   
    Test-NSInitiatorGroupLunAvailability,    New-NSSnapshot,    Get-NSSnapshot,    Set-NSSnapshot,   
    Remove-NSSnapshot,    New-NSSnapshotBulk,    New-NSVolume,    Get-NSVolume,   
    Set-NSVolume,    Remove-NSVolume,    Restore-NSVolume,    Move-NSVolume,   
    Move-NSVolumeBulk,    Stop-NSVolumeMove,    Set-NSVolumeBulkDeDupe,    Set-NSVolumeBulkOnline,   
    Get-NSSubnet,    New-NSActiveDirectoryMembership,    Get-NSActiveDirectoryMembership,    Set-NSActiveDirectoryMembership,   
    Remove-NSActiveDirectoryMembership,    Test-NSActiveDirectoryMembership,    Test-NSActiveDirectoryMembershipUser,    Test-NSActiveDirectoryMembershipGroup,   
    Get-NSSpaceDomain,    Get-NSGroup,    Set-NSGroup,    Reset-NSGroup,   
    Stop-NSGroup,    Test-NSGroupAlert,    Test-NSGroupSoftwareUpdate,    Start-NSGroupSoftwareUpdate,   
    Start-NSGroupSoftwareDownload,    Stop-NSGroupSoftwareDownload,    Resume-NSGroupSoftwareUpdate,    Get-NSGroupDiscoveredList,   
    Test-NSGroupMerge,    Merge-NSGroup,    Get-NSGroupgetEULA,    Test-NSGroupMigrate,   
    Move-NSGroup,    Get-NSGroupTimeZoneList,    New-NSReplicationPartner,    Get-NSReplicationPartner,   
    Set-NSReplicationPartner,    Remove-NSReplicationPartner,    Suspend-NSReplicationPartner,    Resume-NSReplicationPartner,   
    Test-NSReplicationPartner,    New-NSFolder,    Get-NSFolder,    Set-NSFolder,   
    Remove-NSFolder,    Invoke-NSFolderDeDupe,    New-NSNetworkConfig,    Get-NSNetworkConfig,   
    Set-NSNetworkConfig,    Remove-NSNetworkConfig,    Initialize-NSNetworkConfig,    Test-NSNetworkConfig,   
    Get-NSController,    Stop-NSController,    Reset-NSController,    New-NSProtectionSchedule,   
    Get-NSProtectionSchedule,    Set-NSProtectionSchedule,    Remove-NSProtectionSchedule,    New-NSMasterKey,   
    Get-NSMasterKey,    Set-NSMasterKey,    Remove-NSMasterKey,    Clear-NSMasterKeyInactive,   
    New-NSApplicationServer,    Get-NSApplicationServer,    Set-NSApplicationServer,    Remove-NSApplicationServer,   
    Get-NSEvent,    Get-NSFibreChannelPort,    Get-NSApplicationCategory,    Get-NSAuditLog,   
    New-NSInitiator,    Get-NSInitiator,    Remove-NSInitiator,    Get-NSVersion,   
    New-NSPerformancePolicy,    Get-NSPerformancePolicy,    Set-NSPerformancePolicy,    Remove-NSPerformancePolicy,   
    Get-NSJob,    Get-NSDisk,    Set-NSDisk,    Get-NSNetworkInterface,   
    Get-NSUserPolicy,    Set-NSUserPolicy,    Get-NSSoftwareVersion,    New-NSSnapshotCollection,   
    Get-NSSnapshotCollection,    Set-NSSnapshotCollection,    Remove-NSSnapshotCollection,    Get-NSFibreChannelConfig,   
    Update-NSFibreChannelConfig,    Update-NSFibreChannelConfig,    New-NSUser,    Get-NSUser,   
    Set-NSUser,    Remove-NSUser,    Unlock-NSUser,    Get-NSShelf,   
    Set-NSShelf,    Show-NSShelf,    Remove-NSShelf,    Get-NSProtocolEndpoint,   
    Get-NSFibreChannelInterface,    Set-NSFibreChannelInterface,    Get-NSFibreChannelSession,    New-NSArray,   
    Get-NSArray,    Set-NSArray,    Remove-NSArray,    Invoke-NSArray,   
    Stop-NSArray,    Reset-NSArray,    Get-NSAlarm,    Set-NSAlarm,   
    Remove-NSAlarm,    Clear-NSAlarm,    Undo-NSAlarm


# SIG # Begin signature block
# MIIiUwYJKoZIhvcNAQcCoIIiRDCCIkACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCWOVTWOGxP5/AV
# O6YANIQeNmqIyN8Pkfhf4kWBqpg1tKCCEIwwggVRMIIEOaADAgECAhAqlTIY4QtL
# e2/RSyqeww0mMA0GCSqGSIb3DQEBCwUAMIG9MQswCQYDVQQGEwJVUzEXMBUGA1UE
# ChMOVmVyaVNpZ24sIEluYy4xHzAdBgNVBAsTFlZlcmlTaWduIFRydXN0IE5ldHdv
# cmsxOjA4BgNVBAsTMShjKSAyMDA4IFZlcmlTaWduLCBJbmMuIC0gRm9yIGF1dGhv
# cml6ZWQgdXNlIG9ubHkxODA2BgNVBAMTL1ZlcmlTaWduIFVuaXZlcnNhbCBSb290
# IENlcnRpZmljYXRpb24gQXV0aG9yaXR5MB4XDTE2MDUxMjAwMDAwMFoXDTI2MDUx
# MTIzNTk1OVowgZExCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jw
# b3JhdGlvbjEfMB0GA1UECxMWU3ltYW50ZWMgVHJ1c3QgTmV0d29yazFCMEAGA1UE
# AxM5U3ltYW50ZWMgQ2xhc3MgMyBFeHRlbmRlZCBWYWxpZGF0aW9uIENvZGUgU2ln
# bmluZyBDQSAtIEczMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApZCU
# ss4Vva9QGeDEzgpo6PhoHDzlK84LS1feob0ads/HnzSxAG14+SblzJmsdMae4Gzh
# LZEgk4drboRs1S5SF9CP2ers/Owg8g3aP22cJdHb+yDs8ND/SxC2uTkRjfYMokxP
# uB33fdDlz/dcM4BmpNYib3vjeBcGBfTGxpS3/stWKn4P+hjzSANNp24WtxUbfdwv
# 20MOKR7ReG9oGBu3gst+WI/Y0ph/kE27xws8cf7MxMv2o0IQrB3Kg/yRviyqgK+3
# mWlGcdOVIJnNUS6V+KwSHnzitCJpLgvAF3yg/e1cpi4iK2X/fc0xpGOs3yLlk3yi
# ToLCEyy/HIsiPatm7QIDAQABo4IBdTCCAXEwLgYIKwYBBQUHAQEEIjAgMB4GCCsG
# AQUFBzABhhJodHRwOi8vcy5zeW1jZC5jb20wEgYDVR0TAQH/BAgwBgEB/wIBADBg
# BgNVHSAEWTBXMFUGBWeBDAEDMEwwIwYIKwYBBQUHAgEWF2h0dHBzOi8vZC5zeW1j
# Yi5jb20vY3BzMCUGCCsGAQUFBwICMBkaF2h0dHBzOi8vZC5zeW1jYi5jb20vcnBh
# MDYGA1UdHwQvMC0wK6ApoCeGJWh0dHA6Ly9zLnN5bWNiLmNvbS91bml2ZXJzYWwt
# cm9vdC5jcmwwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwMwDgYDVR0PAQH/BAQDAgEG
# MCkGA1UdEQQiMCCkHjAcMRowGAYDVQQDExFTeW1hbnRlY1BLSS0yLTM4ODAdBgNV
# HQ4EFgQUq4sRSQsqAmJ1SpvFAiCghNJL+N4wHwYDVR0jBBgwFoAUtnf6aUhHn1MS
# 1cLqBzJ2B9GXBxkwDQYJKoZIhvcNAQELBQADggEBADAxqBF+Ga4dNNPS18ywHMoB
# oUoWX2jFyk0FWQH0/IUKp88fsBwgZAlBGBK0490yM3KZEytIXUmWESLnucRvBTBN
# bKwzvk1PImLW8WcqFnvGjI4OuZYAnQ5kAZJk6jf4BH4RYm+MLJxdC7j/3X9AzOiI
# 8p0mNEm0H735Wz94cy6B+mka85SPlTB+wrTYlSXSev6KOOiwb/ZvOfDO+oRWEH9W
# p8UUYLRPWjmBSqzhMmBLDhSg9R6hSEOXWZG9HWhmmDAAi8JZ1H72hRt6f7rbZWgO
# rW5ztlQ59GgDhXyhvFOzO6GCP3gkNQKkroWGwgXngHVcBZF57aqNh2kmiheB58Mw
# ggWNMIIDdaADAgECAgphLSPLAAAAAAAhMA0GCSqGSIb3DQEBBQUAMH8xCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAMTIE1pY3Jvc29m
# dCBDb2RlIFZlcmlmaWNhdGlvbiBSb290MB4XDTExMDIyMjE5NDYzOVoXDTIxMDIy
# MjE5NTYzOVowgb0xCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5WZXJpU2lnbiwgSW5j
# LjEfMB0GA1UECxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE6MDgGA1UECxMxKGMp
# IDIwMDggVmVyaVNpZ24sIEluYy4gLSBGb3IgYXV0aG9yaXplZCB1c2Ugb25seTE4
# MDYGA1UEAxMvVmVyaVNpZ24gVW5pdmVyc2FsIFJvb3QgQ2VydGlmaWNhdGlvbiBB
# dXRob3JpdHkwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHYTdesQE0
# 22LXFZv/WFqMIyPWYI6R15CYg3rmWBk4jMX25WSFtKJx++29udrNTQC0yC1zpcdp
# cZUfOTyyRAec6A76TUrEId8pYY8yImGCxYcfbox8XxYgUUTRcE9X6uMc48x57ljY
# DsKzRZPALOeaFyt7ADd6QTN44TPi8xAaf4csvvb190Li5b+HYolfAEvfxd3kdUQy
# QToecW5pywt1RgjRytIrldDP+7lAa2SMV038ExF5hO1eVPY0nwgB8xAlBhdK2vEd
# emZrmGBmpNnv0i6C8fDvCepEyRVq4gNuM9Osn1UAx/YIapS5X9zgM/GEYPlbJxG0
# /Bbyu1ZqgCWNAgMBAAGjgcswgcgwEQYDVR0gBAowCDAGBgRVHSAAMA8GA1UdEwEB
# /wQFMAMBAf8wCwYDVR0PBAQDAgGGMB0GA1UdDgQWBBS2d/ppSEefUxLVwuoHMnYH
# 0ZcHGTAfBgNVHSMEGDAWgBRi+wohW39DbhHaCVRQa/XSlnHxnjBVBgNVHR8ETjBM
# MEqgSKBGhkRodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0
# cy9NaWNyb3NvZnRDb2RlVmVyaWZSb290LmNybDANBgkqhkiG9w0BAQUFAAOCAgEA
# WUdSmjRDPbATxDK4+DfZVVANKqRnZzOUyf/Y9QysjVo5g0htsrtDj3sL81uvNHpP
# nrcI5/4BOBHeLzucPpYLslCC5rVVtGCWE0jtJy0lAnI4s/NlWYpiM3bVbPmV9J01
# TIOgwWf8g7V2k8boUhtZubqFlAo70SgFGxkM8yMXZUZ4DtlzSsC8PcBI4aT4h+UW
# 4VaHZTjhABeiHkQr9k9aKTywG7hfZUtI62qYKV5X4vVi2ENHsy5qE0GnfTgjBg33
# XOZ/us1lBJJSUiZgqKM8Ig2tt7pMMm9S3qubccme6L6fXqatd9dtJZVWKhhDwszB
# buHO30Xv/rdRKnyYtP5mg59rbOx01Z8yHyQ7QzrRBB0ASlul0m1mTMjBTezDATXB
# uHn94Mb2qCmgko09Q3d4ph5MwjgEWOs6gzQExjROE0WyW3IvcmpP5Rp8GGtE48hY
# H45xDIBrTit7PPhK45OSxLCavKZht9N8ynD1+v/NB6LZ6BHMbERQn3GwgtI2pllz
# vbcLW2mGe6Ufx53B0grdLkzCMbaHKo0Qevqnfjxf8LCg9UUF3nkSegKF8R6K05mH
# FylcvnVY1nkBBpVjOfsFFsc9SVGs+muYLcyXbqyzw2+CnACWfyQN6VlAYbNk27n5
# QaG57tlYjf8EV87Y/ur/Z1vOE/yc/PbhZs2joN13EbIwggWiMIIEiqADAgECAhAo
# MknpQET0/8yu7uTbXTF2MA0GCSqGSIb3DQEBCwUAMIGRMQswCQYDVQQGEwJVUzEd
# MBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xHzAdBgNVBAsTFlN5bWFudGVj
# IFRydXN0IE5ldHdvcmsxQjBABgNVBAMTOVN5bWFudGVjIENsYXNzIDMgRXh0ZW5k
# ZWQgVmFsaWRhdGlvbiBDb2RlIFNpZ25pbmcgQ0EgLSBHMzAeFw0xODExMTkwMDAw
# MDBaFw0yMTExMTgyMzU5NTlaMIIBIzETMBEGCysGAQQBgjc8AgEDEwJVUzEZMBcG
# CysGAQQBgjc8AgECDAhEZWxhd2FyZTEZMBcGCysGAQQBgjc8AgEBDAhTYW4gSm9z
# ZTEdMBsGA1UEDxMUUHJpdmF0ZSBPcmdhbml6YXRpb24xEDAOBgNVBAUTBzU2OTky
# NjUxCzAJBgNVBAYTAlVTMRMwEQYDVQQIDApDYWxpZm9ybmlhMREwDwYDVQQHDAhT
# YW4gSm9zZTErMCkGA1UECgwiSGV3bGV0dCBQYWNrYXJkIEVudGVycHJpc2UgQ29t
# cGFueTEWMBQGA1UECwwNTmltYmxlc3RvcmFnZTErMCkGA1UEAwwiSGV3bGV0dCBQ
# YWNrYXJkIEVudGVycHJpc2UgQ29tcGFueTCCASIwDQYJKoZIhvcNAQEBBQADggEP
# ADCCAQoCggEBAKWSqwdskNaMZ0X9Nqn4RKr2Bc131ZU5pS3FWyBGPRumS2sFtCTa
# frdZ9i1xQL0dF3KcNHFFBAnkM/Ig4+UNOR/TIlAD7ssnDxNxfYG07GXxPmAlogoI
# 2s6CWQ1mmLjZoJPHcGqcBsjKvn9sw/OZ1buOjB9SPBn02sh3S2L7dFnlQ1LuJDYa
# sL0BlOzye9leSysvqyhDwMsYv3K7wNpyLoxi7Ee4z/ZBupMZY3LY8F7RMg6W2aHK
# zzqDaP/X867mLqHedB6aK80aQY3C4MVFfOqiLHQFIG7/gVa16aO4U1q8HDUZswRx
# IeiRMOaHje8VRdhtWUU2U+CQC4/RRx1GLsMCAwEAAaOCAV8wggFbMAkGA1UdEwQC
# MAAwDgYDVR0PAQH/BAQDAgeAMCsGA1UdHwQkMCIwIKAeoByGGmh0dHA6Ly9yaC5z
# eW1jYi5jb20vcmguY3JsMGAGA1UdIARZMFcwVQYFZ4EMAQMwTDAjBggrBgEFBQcC
# ARYXaHR0cHM6Ly9kLnN5bWNiLmNvbS9jcHMwJQYIKwYBBQUHAgIwGQwXaHR0cHM6
# Ly9kLnN5bWNiLmNvbS9ycGEwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwMwHwYDVR0j
# BBgwFoAUq4sRSQsqAmJ1SpvFAiCghNJL+N4wHQYDVR0OBBYEFCwOW0/Kegfs4BMM
# 4OMor35vnOjTMFcGCCsGAQUFBwEBBEswSTAfBggrBgEFBQcwAYYTaHR0cDovL3Jo
# LnN5bWNkLmNvbTAmBggrBgEFBQcwAoYaaHR0cDovL3JoLnN5bWNiLmNvbS9yaC5j
# cnQwDQYJKoZIhvcNAQELBQADggEBAHFMScjMHXHXJv6cZj0Kwh1Uphw2DfoLL5rz
# dOYd0vT8PH3WU3WwfJssqsU6LxvPIQlVj75z73PoegdDYLOH2NRfxMGYuw9Ru+4P
# vBEjWpJOeV3j5rM8yubcgF6twn6hkDbI5GsfaK7MJgovXOglzKuV7mCkJMHb8LDT
# qPE6mT9zDUR7YRaavhxV9YiiCnU7RLZd7HwtmJvygF/xkyJg+XYoTolQw7ZEtBVb
# UScbXdDmJO0BWpWlkAF+gMmIBlcdoZ7Avwf4DdQdp+KiDKRlMFTgp0fJ7uzfTZDY
# P+yEYst/1wNjCavw8EoALakact7/SR/x1WP0hR5qALp/jg4gdqIxghEdMIIRGQIB
# ATCBpjCBkTELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0
# aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMUIwQAYDVQQDEzlT
# eW1hbnRlYyBDbGFzcyAzIEV4dGVuZGVkIFZhbGlkYXRpb24gQ29kZSBTaWduaW5n
# IENBIC0gRzMCECgySelARPT/zK7u5NtdMXYwDQYJYIZIAWUDBAIBBQCgfDAQBgor
# BgEEAYI3AgEMMQIwADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEE
# AYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgfztT5WZ0RNJL
# gzWrKwQtn/1wQW4NhqKQdhqWQyGXROMwDQYJKoZIhvcNAQEBBQAEggEAUq1u+cKy
# xBql8prpdHM+V9dpc9MM4GAGQUZPr5UFH+wtXoqtU6W1cwnIxUkfvlBjAu2SjzbU
# sqovwbDxay57sUQ5vwGOwRfyPdYcSuNpe6JGxIpGCXs3c1brJtilmlB41to5OaoP
# 9Z/vc1I5b1b9DdZFn76043u9HODhM0/Xi+cw0Ec2yaA+1BIESqFZzbo7ntmpHCTh
# HHBQkFtBcEJ5icHP0EPLCJgBOV2Dqa1k4hlYhRkmM0/x04gNZW/sRJLJoioibzKZ
# qxpefn/x3k+srSkpmZNHHaR3VEs+e4EAE98REmb7dzWKaTn4/MOWLJbmkgCOPepj
# UFHyZbDyrWYiu6GCDskwgg7FBgorBgEEAYI3AwMBMYIOtTCCDrEGCSqGSIb3DQEH
# AqCCDqIwgg6eAgEDMQ8wDQYJYIZIAWUDBAIBBQAweAYLKoZIhvcNAQkQAQSgaQRn
# MGUCAQEGCWCGSAGG/WwHATAxMA0GCWCGSAFlAwQCAQUABCDPrn7j4eupo5E5ZUeV
# +Er/Zmzs8M0Qk8/w+ICOMKPxlwIRAKvT6C3VSB1hAbgFVFwRiUMYDzIwMjAwNTE1
# MDM0MTAzWqCCC7swggaCMIIFaqADAgECAhAEzT+FaK52xhuw/nFgzKdtMA0GCSqG
# SIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNI
# QTIgQXNzdXJlZCBJRCBUaW1lc3RhbXBpbmcgQ0EwHhcNMTkxMDAxMDAwMDAwWhcN
# MzAxMDE3MDAwMDAwWjBMMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQs
# IEluYy4xJDAiBgNVBAMTG1RJTUVTVEFNUC1TSEEyNTYtMjAxOS0xMC0xNTCCASIw
# DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOlkNZz6qZhlZBvkF9y4KTbMZwlY
# hU0w4Mn/5Ts8EShQrwcx4l0JGML2iYxpCAQj4HctnRXluOihao7/1K7Sehbv+EG1
# HTl1wc8vp6xFfpRtrAMBmTxiPn56/UWXMbT6t9lCPqdVm99aT1gCqDJpIhO+i4It
# xpira5u0yfJlEQx0DbLwCJZ0xOiySKKhFKX4+uGJcEQ7je/7pPTDub0ULOsMKCcl
# gKsQSxYSYAtpIoxOzcbVsmVZIeB8LBKNcA6Pisrg09ezOXdQ0EIsLnrOnGd6OHdU
# QP9PlQQg1OvIzocUCP4dgN3Q5yt46r8fcMbuQhZTNkWbUxlJYp16ApuVFKMCAwEA
# AaOCAzgwggM0MA4GA1UdDwEB/wQEAwIHgDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB
# /wQMMAoGCCsGAQUFBwMIMIIBvwYDVR0gBIIBtjCCAbIwggGhBglghkgBhv1sBwEw
# ggGSMCgGCCsGAQUFBwIBFhxodHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BTMIIB
# ZAYIKwYBBQUHAgIwggFWHoIBUgBBAG4AeQAgAHUAcwBlACAAbwBmACAAdABoAGkA
# cwAgAEMAZQByAHQAaQBmAGkAYwBhAHQAZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUA
# cwAgAGEAYwBjAGUAcAB0AGEAbgBjAGUAIABvAGYAIAB0AGgAZQAgAEQAaQBnAGkA
# QwBlAHIAdAAgAEMAUAAvAEMAUABTACAAYQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkA
# aQBuAGcAIABQAGEAcgB0AHkAIABBAGcAcgBlAGUAbQBlAG4AdAAgAHcAaABpAGMA
# aAAgAGwAaQBtAGkAdAAgAGwAaQBhAGIAaQBsAGkAdAB5ACAAYQBuAGQAIABhAHIA
# ZQAgAGkAbgBjAG8AcgBwAG8AcgBhAHQAZQBkACAAaABlAHIAZQBpAG4AIABiAHkA
# IAByAGUAZgBlAHIAZQBuAGMAZQAuMAsGCWCGSAGG/WwDFTAfBgNVHSMEGDAWgBT0
# tuEgHf4prtLkYaWyoiWyyBc1bjAdBgNVHQ4EFgQUVlMPwcYHp03X2G5XcoBQTOTs
# nsEwcQYDVR0fBGowaDAyoDCgLoYsaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL3No
# YTItYXNzdXJlZC10cy5jcmwwMqAwoC6GLGh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNv
# bS9zaGEyLWFzc3VyZWQtdHMuY3JsMIGFBggrBgEFBQcBAQR5MHcwJAYIKwYBBQUH
# MAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBPBggrBgEFBQcwAoZDaHR0cDov
# L2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0U0hBMkFzc3VyZWRJRFRpbWVz
# dGFtcGluZ0NBLmNydDANBgkqhkiG9w0BAQsFAAOCAQEALoOhRAVKBOO5MlL62YHw
# Grv4CY0juT3YkqHmRhxKL256PGNuNxejGr9YI7JDnJSDTjkJsCzox+HizO3LeWvO
# 3iMBR+2VVIHggHsSsa8Chqk6c2r++J/BjdEhjOQpgsOKC2AAAp0fR8SftApoU39a
# EKb4Iub4U5IxX9iCgy1tE0Kug8EQTqQk9Eec3g8icndcf0/pOZgrV5JE1+9uk9lD
# xwQzY1E3Vp5HBBHDo1hUIdjijlbXST9X/AqfI1579JSN3Z0au996KqbSRaZVDI/2
# TIryls+JRtwxspGQo18zMGBV9fxrMKyh7eRHTjOeZ2ootU3C7VuXgvjLqQhsUwm0
# 9zCCBTEwggQZoAMCAQICEAqhJdbWMht+QeQF2jaXwhUwDQYJKoZIhvcNAQELBQAw
# ZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQ
# d3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMbRGlnaUNlcnQgQXNzdXJlZCBJRCBS
# b290IENBMB4XDTE2MDEwNzEyMDAwMFoXDTMxMDEwNzEyMDAwMFowcjELMAkGA1UE
# BhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2lj
# ZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBBc3N1cmVkIElEIFRpbWVz
# dGFtcGluZyBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAL3QMu5L
# zY9/3am6gpnFOVQoV7YjSsQOB0UzURB90Pl9TWh+57ag9I2ziOSXv2MhkJi/E7xX
# 08PhfgjWahQAOPcuHjvuzKb2Mln+X2U/4Jvr40ZHBhpVfgsnfsCi9aDg3iI/Dv9+
# lfvzo7oiPhisEeTwmQNtO4V8CdPuXciaC1TjqAlxa+DPIhAPdc9xck4Krd9AOly3
# UeGheRTGTSQjMF287DxgaqwvB8z98OpH2YhQXv1mblZhJymJhFHmgudGUP2UKiyn
# 5HU+upgPhH+fMRTWrdXyZMt7HgXQhBlyF/EXBu89zdZN7wZC/aJTKk+FHcQdPK/P
# 2qwQ9d2srOlW/5MCAwEAAaOCAc4wggHKMB0GA1UdDgQWBBT0tuEgHf4prtLkYaWy
# oiWyyBc1bjAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzASBgNVHRMB
# Af8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEFBQcD
# CDB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2lj
# ZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29t
# L0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0fBHoweDA6oDigNoY0
# aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNybDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNz
# dXJlZElEUm9vdENBLmNybDBQBgNVHSAESTBHMDgGCmCGSAGG/WwAAgQwKjAoBggr
# BgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzALBglghkgBhv1s
# BwEwDQYJKoZIhvcNAQELBQADggEBAHGVEulRh1Zpze/d2nyqY3qzeM8GN0CE70uE
# v8rPAwL9xafDDiBCLK938ysfDCFaKrcFNB1qrpn4J6JmvwmqYN92pDqTD/iy0dh8
# GWLoXoIlHsS6HHssIeLWWywUNUMEaLLbdQLgcseY1jxk5R9IEBhfiThhTWJGJIdj
# jJFSLK8pieV4H9YLFKWA1xJHcLN11ZOFk362kmf7U2GJqPVrlsD0WGkNfMgBsbko
# dbeZY4UijGHKeZR+WfyMD+NvtQEmtmyl7odRIeRYYJu6DC0rbaLEfrvEJStHAgh8
# Sa4TtuF8QkIoxhhWz0E0tmZdtnR79VYzIi8iNrJLokqV2PWmjlIxggJNMIICSQIB
# ATCBhjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYD
# VQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFz
# c3VyZWQgSUQgVGltZXN0YW1waW5nIENBAhAEzT+FaK52xhuw/nFgzKdtMA0GCWCG
# SAFlAwQCAQUAoIGYMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAcBgkqhkiG
# 9w0BCQUxDxcNMjAwNTE1MDM0MTAzWjArBgsqhkiG9w0BCRACDDEcMBowGDAWBBQD
# Jb1QXtqWMC3CL0+gHkwovig0xTAvBgkqhkiG9w0BCQQxIgQgj5h58z7wLzzvEHk5
# TX4KuhmBV5wrfMNsawEU8zvPiQ0wDQYJKoZIhvcNAQEBBQAEggEAa2M9qQdOQR+x
# PFcEfTPEpAXJ2MqNJkYfEi0dUOYWklx8aLFa9oDOeJ7B9tXPQsw1sELLZsuoONU3
# QVUAXinJf4pkkHPKYL5IBCpG6pNqnQJT/lUBN6Hy3NGMa744bVX6xnvCrQ7WBZ3R
# D/QqfbPICnJ1laVi37H56LIxSSmlku39Vs8Q4lBGu5tSATNllIB9O20C9cJUV/RN
# pesJ/GoIHyB+NkbfKUny1Nom+s3ERQLNY5wAVfKqqAEhxbqFqRT5MWCBdUZBtLV6
# 6C1TEYCJN8mtt8WY0ZM6YrvRG9IZtlGcUvZ2RgaoZ0vwWRQaKntSZuYRGNB7KAdW
# ixkwSj7o/g==
# SIG # End signature block
