. $PSScriptRoot\scripts\helpers.ps1
. $PSScriptRoot\scripts\AccessControlRecord.ps1
. $PSScriptRoot\scripts\ChapUser.ps1
. $PSScriptRoot\scripts\Pool.ps1
. $PSScriptRoot\scripts\ProtectionTemplate.ps1
. $PSScriptRoot\scripts\Volume.ps1
. $PSScriptRoot\scripts\SpaceDomain.ps1
. $PSScriptRoot\scripts\Group.ps1
. $PSScriptRoot\scripts\ReplicationPartner.ps1
. $PSScriptRoot\scripts\MasterKey.ps1
. $PSScriptRoot\scripts\ApplicationServer.ps1
. $PSScriptRoot\scripts\Event.ps1
. $PSScriptRoot\scripts\FibreChannelPort.ps1
. $PSScriptRoot\scripts\Version.ps1
. $PSScriptRoot\scripts\Initiator.ps1
. $PSScriptRoot\scripts\PerformancePolicy.ps1
. $PSScriptRoot\scripts\KeyManager.ps1
. $PSScriptRoot\scripts\UserPolicy.ps1
. $PSScriptRoot\scripts\SnapshotCollection.ps1
. $PSScriptRoot\scripts\Shelf.ps1
. $PSScriptRoot\scripts\ProtocolEndpoint.ps1
. $PSScriptRoot\scripts\FibreChannelInterface.ps1
. $PSScriptRoot\scripts\FibreChannelSession.ps1
. $PSScriptRoot\scripts\VolumeCollection.ps1
. $PSScriptRoot\scripts\Token.ps1
. $PSScriptRoot\scripts\UserGroup.ps1
. $PSScriptRoot\scripts\Witness.ps1
. $PSScriptRoot\scripts\FibreChannelInitiatorAlias.ps1
. $PSScriptRoot\scripts\InitiatorGroup.ps1
. $PSScriptRoot\scripts\Snapshot.ps1
. $PSScriptRoot\scripts\ActiveDirectoryMembership.ps1
. $PSScriptRoot\scripts\Subnet.ps1
. $PSScriptRoot\scripts\Folder.ps1
. $PSScriptRoot\scripts\NetworkConfig.ps1
. $PSScriptRoot\scripts\Controller.ps1
. $PSScriptRoot\scripts\ProtectionSchedule.ps1
. $PSScriptRoot\scripts\ApplicationCategory.ps1
. $PSScriptRoot\scripts\AuditLog.ps1
. $PSScriptRoot\scripts\Job.ps1
. $PSScriptRoot\scripts\Disk.ps1
. $PSScriptRoot\scripts\NetworkInterface.ps1
. $PSScriptRoot\scripts\SoftwareVersion.ps1
. $PSScriptRoot\scripts\FibreChannelConfig.ps1
. $PSScriptRoot\scripts\User.ps1
. $PSScriptRoot\scripts\Array.ps1
. $PSScriptRoot\scripts\Alarm.ps1

Export-ModuleMember -Function Test-NS2PasswordFormat,   Test-Ns2Type,   Test-NS2ID,     Connect-NSGroup,  Disconnect-NSGroup,
    New-NSAccessControlRecord,    Get-NSAccessControlRecord,    Remove-NSAccessControlRecord,    New-NSChapUser,   
    Get-NSChapUser,    Set-NSChapUser,    Remove-NSChapUser,    New-NSPool,   
    Get-NSPool,    Set-NSPool,    Remove-NSPool,    Merge-NSPool,   
    Invoke-NSPoolDeDupe,    New-NSProtectionTemplate,    Get-NSProtectionTemplate,    Set-NSProtectionTemplate,   
    Remove-NSProtectionTemplate,    New-NSVolume,    Get-NSVolume,    Set-NSVolume,   
    Remove-NSVolume,    Restore-NSVolume,    Move-NSVolume,    Move-NSVolumeBulk,   
    Stop-NSVolumeMove,    Set-NSVolumeBulkDeDupe,    Set-NSVolumeBulkOnline,    Get-NSSpaceDomain,   
    Get-NSGroup,    Set-NSGroup,    Reset-NSGroup,    Stop-NSGroup,   
    Test-NSGroupAlert,    Test-NSGroupSoftwareUpdate,    Start-NSGroupSoftwareUpdate,    Start-NSGroupSoftwareDownload,   
    Stop-NSGroupSoftwareDownload,    Resume-NSGroupSoftwareUpdate,    Get-NSGroupDiscoveredList,    Test-NSGroupMerge,   
    Merge-NSGroup,    Get-NSGroupgetEULA,    Test-NSGroupMigrate,    Move-NSGroup,   
    Get-NSGroupTimeZoneList,    New-NSReplicationPartner,    Get-NSReplicationPartner,    Set-NSReplicationPartner,   
    Remove-NSReplicationPartner,    Suspend-NSReplicationPartner,    Resume-NSReplicationPartner,    Test-NSReplicationPartner,   
    New-NSMasterKey,    Get-NSMasterKey,    Set-NSMasterKey,    Remove-NSMasterKey,   
    Clear-NSMasterKeyInactive,    New-NSApplicationServer,    Get-NSApplicationServer,    Set-NSApplicationServer,   
    Remove-NSApplicationServer,    Get-NSEvent,    Get-NSFibreChannelPort,    Get-NSVersion,   
    New-NSInitiator,    Get-NSInitiator,    Remove-NSInitiator,    New-NSPerformancePolicy,   
    Get-NSPerformancePolicy,    Set-NSPerformancePolicy,    Remove-NSPerformancePolicy,    New-NSKeyManager,   
    Get-NSKeyManager,    Set-NSKeyManager,    Remove-NSKeyManager,    Move-NSKeyManager,   
    Get-NSUserPolicy,    Set-NSUserPolicy,    New-NSSnapshotCollection,    Get-NSSnapshotCollection,   
    Set-NSSnapshotCollection,    Remove-NSSnapshotCollection,    Get-NSShelf,    Set-NSShelf,   
    Show-NSShelf,    Remove-NSShelf,    Get-NSProtocolEndpoint,    Get-NSFibreChannelInterface,   
    Set-NSFibreChannelInterface,    Get-NSFibreChannelSession,    New-NSVolumeCollection,    Get-NSVolumeCollection,   
    Set-NSVolumeCollection,    Remove-NSVolumeCollection,    Invoke-NSVolumeCollectionPromote,    Invoke-NSVolumeCollectionDemote,   
    Start-NSVolumeCollectionHandover,    Stop-NSVolumeCollectionHandover,    Test-NSVolumeCollection,    New-NSToken,   
    Get-NSToken,    Remove-NSToken,    Get-NSTokenUserDetails,    New-NSUserGroup,   
    Get-NSUserGroup,    Set-NSUserGroup,    Remove-NSUserGroup,    New-NSWitness,   
    Get-NSWitness,    Remove-NSWitness,    Test-NSWitness,    Get-NSFibreChannelInitiatorAlias,   
    New-NSInitiatorGroup,    Get-NSInitiatorGroup,    Set-NSInitiatorGroup,    Remove-NSInitiatorGroup,   
    Resolve-NSInitiatorGroupMerge,    Test-NSInitiatorGroupLunAvailability,    New-NSSnapshot,    Get-NSSnapshot,   
    Set-NSSnapshot,    Remove-NSSnapshot,    New-NSSnapshotBulk,    New-NSActiveDirectoryMembership,   
    Get-NSActiveDirectoryMembership,    Set-NSActiveDirectoryMembership,    Remove-NSActiveDirectoryMembership,    Test-NSActiveDirectoryMembership,   
    Test-NSActiveDirectoryMembershipUser,    Test-NSActiveDirectoryMembershipGroup,    Get-NSSubnet,    New-NSFolder,   
    Get-NSFolder,    Set-NSFolder,    Remove-NSFolder,    Invoke-NSFolderDeDupe,   
    New-NSNetworkConfig,    Get-NSNetworkConfig,    Set-NSNetworkConfig,    Remove-NSNetworkConfig,   
    Initialize-NSNetworkConfig,    Test-NSNetworkConfig,    Get-NSController,    Stop-NSController,   
    Reset-NSController,    New-NSProtectionSchedule,    Get-NSProtectionSchedule,    Set-NSProtectionSchedule,   
    Remove-NSProtectionSchedule,    Get-NSApplicationCategory,    Get-NSAuditLog,    Get-NSJob,   
    Get-NSDisk,    Set-NSDisk,    Get-NSNetworkInterface,    Get-NSSoftwareVersion,   
    Get-NSFibreChannelConfig,    Update-NSFibreChannelConfig,    Update-NSFibreChannelConfig,    New-NSUser,   
    Get-NSUser,    Set-NSUser,    Remove-NSUser,    Unlock-NSUser,   
    New-NSArray,    Get-NSArray,    Set-NSArray,    Remove-NSArray,   
    Invoke-NSArray,    Stop-NSArray,    Reset-NSArray,    Get-NSAlarm,   
    Set-NSAlarm,    Remove-NSAlarm,    Clear-NSAlarm,    Undo-NSAlarm


# SIG # Begin signature block
# MIIiUgYJKoZIhvcNAQcCoIIiQzCCIj8CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCFjWFQHE2SJi4X
# wPKmzFtk403t63bMO586bog2GmxxZKCCEIwwggVRMIIEOaADAgECAhAqlTIY4QtL
# e2/RSyqeww0mMA0GCSqGSIb3DQEBCwUAMIG9MQswCQYDVQQGEwJVUzEXMBUGA1UE
# ChMOVmVyaVNpZ24sIEluYy4xHzAdBgNVBAsTFlZlcmlTaWduIFRydXN0IE5ldHdv
# cmsxOjA4BgNVBAsTMShjKSAyMDA4IFZlcmlTaWduLCBJbmMuIC0gRm9yIGF1dGhv
# cml6ZWQgdXNlIG9ubHkxODA2BgNVBAMTL1ZlcmlTaWduIFVuaXZlcnNhbCBSb290
# IENlcnRpZmljYXRpb24gQXV0aG9yaXR5MB4XDTE2MDUxMjAwMDAwMFoXDTI2MDUx
# MTIzNTk1OVowgZExCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jw
# b3JhdGlvbjEfMB0GA1UECxMWU3ltYW50ZWMgVHJ1c3QgTmV0d29yazFCMEAGA1UE
# AxM5U3ltYW50ZWMgQ2xhc3MgMyBFeHRlbmRlZCBWYWxpZGF0aW9uIENvZGUgU2ln
# bmluZyBDQSAtIEczMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApZCU
# ss4Vva9QGeDEzgpo6PhoHDzlK84LS1feob0ads/HnzSxAG14+SblzJmsdMae4Gzh
# LZEgk4drboRs1S5SF9CP2ers/Owg8g3aP22cJdHb+yDs8ND/SxC2uTkRjfYMokxP
# uB33fdDlz/dcM4BmpNYib3vjeBcGBfTGxpS3/stWKn4P+hjzSANNp24WtxUbfdwv
# 20MOKR7ReG9oGBu3gst+WI/Y0ph/kE27xws8cf7MxMv2o0IQrB3Kg/yRviyqgK+3
# mWlGcdOVIJnNUS6V+KwSHnzitCJpLgvAF3yg/e1cpi4iK2X/fc0xpGOs3yLlk3yi
# ToLCEyy/HIsiPatm7QIDAQABo4IBdTCCAXEwLgYIKwYBBQUHAQEEIjAgMB4GCCsG
# AQUFBzABhhJodHRwOi8vcy5zeW1jZC5jb20wEgYDVR0TAQH/BAgwBgEB/wIBADBg
# BgNVHSAEWTBXMFUGBWeBDAEDMEwwIwYIKwYBBQUHAgEWF2h0dHBzOi8vZC5zeW1j
# Yi5jb20vY3BzMCUGCCsGAQUFBwICMBkaF2h0dHBzOi8vZC5zeW1jYi5jb20vcnBh
# MDYGA1UdHwQvMC0wK6ApoCeGJWh0dHA6Ly9zLnN5bWNiLmNvbS91bml2ZXJzYWwt
# cm9vdC5jcmwwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwMwDgYDVR0PAQH/BAQDAgEG
# MCkGA1UdEQQiMCCkHjAcMRowGAYDVQQDExFTeW1hbnRlY1BLSS0yLTM4ODAdBgNV
# HQ4EFgQUq4sRSQsqAmJ1SpvFAiCghNJL+N4wHwYDVR0jBBgwFoAUtnf6aUhHn1MS
# 1cLqBzJ2B9GXBxkwDQYJKoZIhvcNAQELBQADggEBADAxqBF+Ga4dNNPS18ywHMoB
# oUoWX2jFyk0FWQH0/IUKp88fsBwgZAlBGBK0490yM3KZEytIXUmWESLnucRvBTBN
# bKwzvk1PImLW8WcqFnvGjI4OuZYAnQ5kAZJk6jf4BH4RYm+MLJxdC7j/3X9AzOiI
# 8p0mNEm0H735Wz94cy6B+mka85SPlTB+wrTYlSXSev6KOOiwb/ZvOfDO+oRWEH9W
# p8UUYLRPWjmBSqzhMmBLDhSg9R6hSEOXWZG9HWhmmDAAi8JZ1H72hRt6f7rbZWgO
# rW5ztlQ59GgDhXyhvFOzO6GCP3gkNQKkroWGwgXngHVcBZF57aqNh2kmiheB58Mw
# ggWNMIIDdaADAgECAgphLSPLAAAAAAAhMA0GCSqGSIb3DQEBBQUAMH8xCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAMTIE1pY3Jvc29m
# dCBDb2RlIFZlcmlmaWNhdGlvbiBSb290MB4XDTExMDIyMjE5NDYzOVoXDTIxMDIy
# MjE5NTYzOVowgb0xCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5WZXJpU2lnbiwgSW5j
# LjEfMB0GA1UECxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE6MDgGA1UECxMxKGMp
# IDIwMDggVmVyaVNpZ24sIEluYy4gLSBGb3IgYXV0aG9yaXplZCB1c2Ugb25seTE4
# MDYGA1UEAxMvVmVyaVNpZ24gVW5pdmVyc2FsIFJvb3QgQ2VydGlmaWNhdGlvbiBB
# dXRob3JpdHkwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHYTdesQE0
# 22LXFZv/WFqMIyPWYI6R15CYg3rmWBk4jMX25WSFtKJx++29udrNTQC0yC1zpcdp
# cZUfOTyyRAec6A76TUrEId8pYY8yImGCxYcfbox8XxYgUUTRcE9X6uMc48x57ljY
# DsKzRZPALOeaFyt7ADd6QTN44TPi8xAaf4csvvb190Li5b+HYolfAEvfxd3kdUQy
# QToecW5pywt1RgjRytIrldDP+7lAa2SMV038ExF5hO1eVPY0nwgB8xAlBhdK2vEd
# emZrmGBmpNnv0i6C8fDvCepEyRVq4gNuM9Osn1UAx/YIapS5X9zgM/GEYPlbJxG0
# /Bbyu1ZqgCWNAgMBAAGjgcswgcgwEQYDVR0gBAowCDAGBgRVHSAAMA8GA1UdEwEB
# /wQFMAMBAf8wCwYDVR0PBAQDAgGGMB0GA1UdDgQWBBS2d/ppSEefUxLVwuoHMnYH
# 0ZcHGTAfBgNVHSMEGDAWgBRi+wohW39DbhHaCVRQa/XSlnHxnjBVBgNVHR8ETjBM
# MEqgSKBGhkRodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0
# cy9NaWNyb3NvZnRDb2RlVmVyaWZSb290LmNybDANBgkqhkiG9w0BAQUFAAOCAgEA
# WUdSmjRDPbATxDK4+DfZVVANKqRnZzOUyf/Y9QysjVo5g0htsrtDj3sL81uvNHpP
# nrcI5/4BOBHeLzucPpYLslCC5rVVtGCWE0jtJy0lAnI4s/NlWYpiM3bVbPmV9J01
# TIOgwWf8g7V2k8boUhtZubqFlAo70SgFGxkM8yMXZUZ4DtlzSsC8PcBI4aT4h+UW
# 4VaHZTjhABeiHkQr9k9aKTywG7hfZUtI62qYKV5X4vVi2ENHsy5qE0GnfTgjBg33
# XOZ/us1lBJJSUiZgqKM8Ig2tt7pMMm9S3qubccme6L6fXqatd9dtJZVWKhhDwszB
# buHO30Xv/rdRKnyYtP5mg59rbOx01Z8yHyQ7QzrRBB0ASlul0m1mTMjBTezDATXB
# uHn94Mb2qCmgko09Q3d4ph5MwjgEWOs6gzQExjROE0WyW3IvcmpP5Rp8GGtE48hY
# H45xDIBrTit7PPhK45OSxLCavKZht9N8ynD1+v/NB6LZ6BHMbERQn3GwgtI2pllz
# vbcLW2mGe6Ufx53B0grdLkzCMbaHKo0Qevqnfjxf8LCg9UUF3nkSegKF8R6K05mH
# FylcvnVY1nkBBpVjOfsFFsc9SVGs+muYLcyXbqyzw2+CnACWfyQN6VlAYbNk27n5
# QaG57tlYjf8EV87Y/ur/Z1vOE/yc/PbhZs2joN13EbIwggWiMIIEiqADAgECAhAo
# MknpQET0/8yu7uTbXTF2MA0GCSqGSIb3DQEBCwUAMIGRMQswCQYDVQQGEwJVUzEd
# MBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xHzAdBgNVBAsTFlN5bWFudGVj
# IFRydXN0IE5ldHdvcmsxQjBABgNVBAMTOVN5bWFudGVjIENsYXNzIDMgRXh0ZW5k
# ZWQgVmFsaWRhdGlvbiBDb2RlIFNpZ25pbmcgQ0EgLSBHMzAeFw0xODExMTkwMDAw
# MDBaFw0yMTExMTgyMzU5NTlaMIIBIzETMBEGCysGAQQBgjc8AgEDEwJVUzEZMBcG
# CysGAQQBgjc8AgECDAhEZWxhd2FyZTEZMBcGCysGAQQBgjc8AgEBDAhTYW4gSm9z
# ZTEdMBsGA1UEDxMUUHJpdmF0ZSBPcmdhbml6YXRpb24xEDAOBgNVBAUTBzU2OTky
# NjUxCzAJBgNVBAYTAlVTMRMwEQYDVQQIDApDYWxpZm9ybmlhMREwDwYDVQQHDAhT
# YW4gSm9zZTErMCkGA1UECgwiSGV3bGV0dCBQYWNrYXJkIEVudGVycHJpc2UgQ29t
# cGFueTEWMBQGA1UECwwNTmltYmxlc3RvcmFnZTErMCkGA1UEAwwiSGV3bGV0dCBQ
# YWNrYXJkIEVudGVycHJpc2UgQ29tcGFueTCCASIwDQYJKoZIhvcNAQEBBQADggEP
# ADCCAQoCggEBAKWSqwdskNaMZ0X9Nqn4RKr2Bc131ZU5pS3FWyBGPRumS2sFtCTa
# frdZ9i1xQL0dF3KcNHFFBAnkM/Ig4+UNOR/TIlAD7ssnDxNxfYG07GXxPmAlogoI
# 2s6CWQ1mmLjZoJPHcGqcBsjKvn9sw/OZ1buOjB9SPBn02sh3S2L7dFnlQ1LuJDYa
# sL0BlOzye9leSysvqyhDwMsYv3K7wNpyLoxi7Ee4z/ZBupMZY3LY8F7RMg6W2aHK
# zzqDaP/X867mLqHedB6aK80aQY3C4MVFfOqiLHQFIG7/gVa16aO4U1q8HDUZswRx
# IeiRMOaHje8VRdhtWUU2U+CQC4/RRx1GLsMCAwEAAaOCAV8wggFbMAkGA1UdEwQC
# MAAwDgYDVR0PAQH/BAQDAgeAMCsGA1UdHwQkMCIwIKAeoByGGmh0dHA6Ly9yaC5z
# eW1jYi5jb20vcmguY3JsMGAGA1UdIARZMFcwVQYFZ4EMAQMwTDAjBggrBgEFBQcC
# ARYXaHR0cHM6Ly9kLnN5bWNiLmNvbS9jcHMwJQYIKwYBBQUHAgIwGQwXaHR0cHM6
# Ly9kLnN5bWNiLmNvbS9ycGEwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwMwHwYDVR0j
# BBgwFoAUq4sRSQsqAmJ1SpvFAiCghNJL+N4wHQYDVR0OBBYEFCwOW0/Kegfs4BMM
# 4OMor35vnOjTMFcGCCsGAQUFBwEBBEswSTAfBggrBgEFBQcwAYYTaHR0cDovL3Jo
# LnN5bWNkLmNvbTAmBggrBgEFBQcwAoYaaHR0cDovL3JoLnN5bWNiLmNvbS9yaC5j
# cnQwDQYJKoZIhvcNAQELBQADggEBAHFMScjMHXHXJv6cZj0Kwh1Uphw2DfoLL5rz
# dOYd0vT8PH3WU3WwfJssqsU6LxvPIQlVj75z73PoegdDYLOH2NRfxMGYuw9Ru+4P
# vBEjWpJOeV3j5rM8yubcgF6twn6hkDbI5GsfaK7MJgovXOglzKuV7mCkJMHb8LDT
# qPE6mT9zDUR7YRaavhxV9YiiCnU7RLZd7HwtmJvygF/xkyJg+XYoTolQw7ZEtBVb
# UScbXdDmJO0BWpWlkAF+gMmIBlcdoZ7Avwf4DdQdp+KiDKRlMFTgp0fJ7uzfTZDY
# P+yEYst/1wNjCavw8EoALakact7/SR/x1WP0hR5qALp/jg4gdqIxghEcMIIRGAIB
# ATCBpjCBkTELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0
# aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMUIwQAYDVQQDEzlT
# eW1hbnRlYyBDbGFzcyAzIEV4dGVuZGVkIFZhbGlkYXRpb24gQ29kZSBTaWduaW5n
# IENBIC0gRzMCECgySelARPT/zK7u5NtdMXYwDQYJYIZIAWUDBAIBBQCgfDAQBgor
# BgEEAYI3AgEMMQIwADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEE
# AYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg34qqSDfIehpt
# LtppfLYsYc3wd4OVg33+yslzQWCA8lMwDQYJKoZIhvcNAQEBBQAEggEAWyQxP+ks
# N9vg9pJDThrJtA62nVNHFLWoVJErF0w6uI400vTYK3FdmmuAN/Z87K1jng1f22H/
# Dc+LvSaN8QdMxCE5kkXZ9wftAVCzTvZLatu8YvctFnqdqv2fgjjURO3E/UKgD4JS
# kzEwLV130wq3Cm/WviA0TFfHjMDYcHXErl0nh2/rozEvJ50A9JqnhsCXE2a9xOz4
# ENb8XNOWKyxqZGbavVgUiySadazg63w56u47QkuJIJM9GzHVDcKG5TBl3mfU2BBd
# WM7pQ5V0SJlhPn6jce8gDzNAmIVtp3e2HS/diWnKVIxTIx8GUjPi+TVWNmlQUssg
# H+QT64UiKxWIb6GCDsgwgg7EBgorBgEEAYI3AwMBMYIOtDCCDrAGCSqGSIb3DQEH
# AqCCDqEwgg6dAgEDMQ8wDQYJYIZIAWUDBAIBBQAwdwYLKoZIhvcNAQkQAQSgaARm
# MGQCAQEGCWCGSAGG/WwHATAxMA0GCWCGSAFlAwQCAQUABCCXn87Vh3AgxFH02e0f
# T71iRmBrAOCg7csX1UGSp+EmdgIQDfGDyc1FwYmkta0rmc9t9RgPMjAyMDA5MDMx
# MDQ4MTBaoIILuzCCBoIwggVqoAMCAQICEATNP4VornbGG7D+cWDMp20wDQYJKoZI
# hvcNAQELBQAwcjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZ
# MBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hB
# MiBBc3N1cmVkIElEIFRpbWVzdGFtcGluZyBDQTAeFw0xOTEwMDEwMDAwMDBaFw0z
# MDEwMTcwMDAwMDBaMEwxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjEkMCIGA1UEAxMbVElNRVNUQU1QLVNIQTI1Ni0yMDE5LTEwLTE1MIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA6WQ1nPqpmGVkG+QX3LgpNsxnCViF
# TTDgyf/lOzwRKFCvBzHiXQkYwvaJjGkIBCPgdy2dFeW46KFqjv/UrtJ6Fu/4QbUd
# OXXBzy+nrEV+lG2sAwGZPGI+fnr9RZcxtPq32UI+p1Wb31pPWAKoMmkiE76Lgi3G
# mKtrm7TJ8mURDHQNsvAIlnTE6LJIoqEUpfj64YlwRDuN7/uk9MO5vRQs6wwoJyWA
# qxBLFhJgC2kijE7NxtWyZVkh4HwsEo1wDo+KyuDT17M5d1DQQiwues6cZ3o4d1RA
# /0+VBCDU68jOhxQI/h2A3dDnK3jqvx9wxu5CFlM2RZtTGUlinXoCm5UUowIDAQAB
# o4IDODCCAzQwDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/
# BAwwCgYIKwYBBQUHAwgwggG/BgNVHSAEggG2MIIBsjCCAaEGCWCGSAGG/WwHATCC
# AZIwKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwggFk
# BggrBgEFBQcCAjCCAVYeggFSAEEAbgB5ACAAdQBzAGUAIABvAGYAIAB0AGgAaQBz
# ACAAQwBlAHIAdABpAGYAaQBjAGEAdABlACAAYwBvAG4AcwB0AGkAdAB1AHQAZQBz
# ACAAYQBjAGMAZQBwAHQAYQBuAGMAZQAgAG8AZgAgAHQAaABlACAARABpAGcAaQBD
# AGUAcgB0ACAAQwBQAC8AQwBQAFMAIABhAG4AZAAgAHQAaABlACAAUgBlAGwAeQBp
# AG4AZwAgAFAAYQByAHQAeQAgAEEAZwByAGUAZQBtAGUAbgB0ACAAdwBoAGkAYwBo
# ACAAbABpAG0AaQB0ACAAbABpAGEAYgBpAGwAaQB0AHkAIABhAG4AZAAgAGEAcgBl
# ACAAaQBuAGMAbwByAHAAbwByAGEAdABlAGQAIABoAGUAcgBlAGkAbgAgAGIAeQAg
# AHIAZQBmAGUAcgBlAG4AYwBlAC4wCwYJYIZIAYb9bAMVMB8GA1UdIwQYMBaAFPS2
# 4SAd/imu0uRhpbKiJbLIFzVuMB0GA1UdDgQWBBRWUw/BxgenTdfYbldygFBM5Oye
# wTBxBgNVHR8EajBoMDKgMKAuhixodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vc2hh
# Mi1hc3N1cmVkLXRzLmNybDAyoDCgLoYsaHR0cDovL2NybDQuZGlnaWNlcnQuY29t
# L3NoYTItYXNzdXJlZC10cy5jcmwwgYUGCCsGAQUFBwEBBHkwdzAkBggrBgEFBQcw
# AYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tME8GCCsGAQUFBzAChkNodHRwOi8v
# Y2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEVGltZXN0
# YW1waW5nQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQAug6FEBUoE47kyUvrZgfAa
# u/gJjSO5PdiSoeZGHEovbno8Y243F6Mav1gjskOclINOOQmwLOjH4eLM7ct5a87e
# IwFH7ZVUgeCAexKxrwKGqTpzav74n8GN0SGM5CmCw4oLYAACnR9HxJ+0CmhTf1oQ
# pvgi5vhTkjFf2IKDLW0TQq6DwRBOpCT0R5zeDyJyd1x/T+k5mCtXkkTX726T2UPH
# BDNjUTdWnkcEEcOjWFQh2OKOVtdJP1f8Cp8jXnv0lI3dnRq733oqptJFplUMj/ZM
# ivKWz4lG3DGykZCjXzMwYFX1/GswrKHt5EdOM55naii1TcLtW5eC+MupCGxTCbT3
# MIIFMTCCBBmgAwIBAgIQCqEl1tYyG35B5AXaNpfCFTANBgkqhkiG9w0BAQsFADBl
# MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3
# d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJv
# b3QgQ0EwHhcNMTYwMTA3MTIwMDAwWhcNMzEwMTA3MTIwMDAwWjByMQswCQYDVQQG
# EwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNl
# cnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgVGltZXN0
# YW1waW5nIENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvdAy7kvN
# j3/dqbqCmcU5VChXtiNKxA4HRTNREH3Q+X1NaH7ntqD0jbOI5Je/YyGQmL8TvFfT
# w+F+CNZqFAA49y4eO+7MpvYyWf5fZT/gm+vjRkcGGlV+Cyd+wKL1oODeIj8O/36V
# +/OjuiI+GKwR5PCZA207hXwJ0+5dyJoLVOOoCXFr4M8iEA91z3FyTgqt30A6XLdR
# 4aF5FMZNJCMwXbzsPGBqrC8HzP3w6kfZiFBe/WZuVmEnKYmEUeaC50ZQ/ZQqLKfk
# dT66mA+Ef58xFNat1fJky3seBdCEGXIX8RcG7z3N1k3vBkL9olMqT4UdxB08r8/a
# rBD13ays6Vb/kwIDAQABo4IBzjCCAcowHQYDVR0OBBYEFPS24SAd/imu0uRhpbKi
# JbLIFzVuMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3zbcgPMBIGA1UdEwEB
# /wQIMAYBAf8CAQAwDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMI
# MHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNl
# cnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MIGBBgNVHR8EejB4MDqgOKA2hjRo
# dHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0Eu
# Y3JsMDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1
# cmVkSURSb290Q0EuY3JsMFAGA1UdIARJMEcwOAYKYIZIAYb9bAACBDAqMCgGCCsG
# AQUFBwIBFhxodHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BTMAsGCWCGSAGG/WwH
# ATANBgkqhkiG9w0BAQsFAAOCAQEAcZUS6VGHVmnN793afKpjerN4zwY3QITvS4S/
# ys8DAv3Fp8MOIEIsr3fzKx8MIVoqtwU0HWqumfgnoma/Capg33akOpMP+LLR2HwZ
# YuhegiUexLoceywh4tZbLBQ1QwRostt1AuByx5jWPGTlH0gQGF+JOGFNYkYkh2OM
# kVIsrymJ5Xgf1gsUpYDXEkdws3XVk4WTfraSZ/tTYYmo9WuWwPRYaQ18yAGxuSh1
# t5ljhSKMYcp5lH5Z/IwP42+1ASa2bKXuh1Eh5Fhgm7oMLSttosR+u8QlK0cCCHxJ
# rhO24XxCQijGGFbPQTS2Zl22dHv1VjMiLyI2skuiSpXY9aaOUjGCAk0wggJJAgEB
# MIGGMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNV
# BAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNIQTIgQXNz
# dXJlZCBJRCBUaW1lc3RhbXBpbmcgQ0ECEATNP4VornbGG7D+cWDMp20wDQYJYIZI
# AWUDBAIBBQCggZgwGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMBwGCSqGSIb3
# DQEJBTEPFw0yMDA5MDMxMDQ4MTBaMCsGCyqGSIb3DQEJEAIMMRwwGjAYMBYEFAMl
# vVBe2pYwLcIvT6AeTCi+KDTFMC8GCSqGSIb3DQEJBDEiBCDkeiYu3iN43gBCyK4c
# 7JzfHSAPvcosEv9rE3HOJ71VnzANBgkqhkiG9w0BAQEFAASCAQCIKotARTto3axT
# aMvLru5SEg4Rbc+MgFiYOzFsaSQT80VCuboDNJnKmJu5yJRFQO9560HBfgWVzHqj
# xP0HCedZMbI09E+JcaFb025qknrx3Gq0pcasa4ugDByzRRAVKMPgAHdg6GwCDjq3
# Y7HXFRXZYxq+yFPralC9N5bhqsczBISq0zauUyYBFKH5GG7MUHr/u9zzEM6Of4xU
# BG3mKiTEZ+UcNzrIs4CTd2HRTVE2fB83y1jMNevFqU15Yq+APXAr8H/9YWmeZ07o
# w7geKFdKB+D1JaO/qT/sgiflqLnDVclofHOzewbviHnHrR8MMu/aeAJ4Gn/eKgLU
# 10YosF1v
# SIG # End signature block
